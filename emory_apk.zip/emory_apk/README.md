# Emory APK

Telefondan APK almak için:

1. github.com'da ücretsiz hesap aç, yeni bir **repository** oluştur.
2. Bu klasörün içindeki her şeyi (`main.py`, `buildozer.spec`, `.github` klasörü) repoya yükle.
   `.github/workflows/build.yml` dosyasının yolu aynen böyle kalmalı.
3. Repoda **Actions** sekmesine gir, **Build APK** çalışmasını bekle (ilk seferde 15-30 dk sürebilir).
4. Çalışma bitince sayfanın altındaki **Artifacts → emory-apk** dosyasını indir, zip'ten çıkan `.apk`'yı telefona kur.
   (Telefonda "bilinmeyen kaynaklardan yüklemeye izin ver" açık olmalı.)

## Orijinal koddan farklar

- VLC yerine Android'in kendi MediaPlayer'ı kullanılıyor.
- 8D modu ve equalizer kaldırıldı (VLC'ye bağlıydı).
- İndirmeler MP3 yerine m4a olarak kaydediliyor (Android'de FFmpeg yok).
- Veritabanı ve indirilenler uygulamanın kendi klasörüne kaydediliyor.
- Şarkı bitince sıradakine geçiş, tekrar ve karıştır eklendi.
